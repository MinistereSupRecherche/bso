function include_text(container_id, lang) {
$('#'+container_id).html(translation[container_id][lang]); 
}
